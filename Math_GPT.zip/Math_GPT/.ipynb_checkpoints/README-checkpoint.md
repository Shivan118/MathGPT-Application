pip install python-decouple -> app.py
pip install latex2sympy -> main.py
pip install SpeechRecognition gtts
pip install pyaudio


Questions:
1. Combine terms: 12a + 26b -4b – 16a
Answer: -4a + 22b.

2. Simplify: (4 – 5) – (13 – 18 + 2).
Answer: 2

3. Factor: 5x2 – 15x – 20.
Answer: 5(x-4)(x+1).

4. Priya had 16 Red Balls, 2 Green Balls, 9  Blue Balls, and 1 Multicolor Ball. If He Lost 9 Red Balls, 1 Green Ball, and 3 Blue Balls. How Many Balls would be Left? 
Answer:  15 balls.

5. Look at this series: 36, 34, 30, 28, …, 22 What number should come to fill in the blank space.
Answer: Answer: 24

6. 27 is a perfect cube. If true then what is the perfect cube of 27? 
Answer: 3




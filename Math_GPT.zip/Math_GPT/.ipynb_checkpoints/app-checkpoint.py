import streamlit as st
from decouple import config  # Import the config function from python-decouple
import openai

# Get the API key from the .env file using config()
api_key = config('OPENAI_API_KEY')

openai.api_key = api_key

# Define the ask_math_question function
def ask_math_question(question):
    conversation = [
        {"role": "system", "content": "You are a math tutor."},
        {"role": "user", "content": question}
    ]

    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=conversation
    )

    reply = response['choices'][0]['message']['content']
    return reply

def main():
    st.title("MathGPT - Math Assistant")

    # Define a user profile with user-specific settings (language, units, etc.)
    user_profile = {
        "language": "English",
        "preferred_units": "imperial",
        # Add more user-specific settings here
    }

    # Sidebar for User Profile Customization
    st.sidebar.header("User Profile Settings")
    user_profile["language"] = st.selectbox("Language", ["English", "Spanish", "French"])
    user_profile["preferred_units"] = st.selectbox("Preferred Units", ["Imperial", "Metric"])

    # User Input for Math Questions
    #question = st.text_input("Ask a math question:")

    # User Input for Math Questions
    st.subheader("Ask a math question:")
    
    # Increase the height of the input field by setting the height parameter
    question = st.text_area("", height=150, key="math_question")

    if st.button("Submit"):
        # Send the user question to MathGPT and get the answer
        answer = ask_math_question(question)

        # Display the answer
        st.write(f"**Answer:** {answer}")

# Add more features and complexity based on your specific requirements
# For example, user accounts, history, error handling, customizable behavior, etc.

if __name__ == "__main__":
    main()
